const phases = [
  {
    number: "01",
    title: "Business Understanding",
    body: "Membantu toko pakaian mengurangi stok musim lalu sebelum batas waktu penjualan, sambil menjaga laba kotor. Keputusan yang dibantu aplikasi adalah pilihan diskon mingguan.",
  },
  {
    number: "02",
    title: "Data Understanding",
    body: "Analisis memakai dataset sintetis ritel dengan kategori Clothing. sales_data.csv menyediakan penjualan dan Demand; retail_store_inventory.csv menyediakan penjualan dan Demand Forecast. Data mencakup tanggal, toko, produk, harga, diskon, musim, serta persediaan.",
  },
  {
    number: "03",
    title: "Data Preparation",
    body: "Aplikasi menyaring baris Clothing, memeriksa kolom wajib dan nilai harga, permintaan, diskon, serta jumlah unit, lalu menyimpan observasi untuk ringkasan per tahun. Prakiraan negatif pada data inventory dikoreksi menjadi nol dan dihitung sebagai koreksi.",
  },
  {
    number: "04",
    title: "Modeling",
    body: "Makalah menguji regresi Log-Log untuk mengestimasi elastisitas harga. Karena hasilnya lemah, simulator website memakai elastisitas skenario yang dipilih pengguna, permintaan dasar sebagai bagian dari rata-rata mingguan, serta HPP sebagai bagian dari harga referensi.",
  },
  {
    number: "05",
    title: "Evaluation",
    body: "Simulator membandingkan 1.296 jadwal diskon (0%, 5%, 10%, 15%, 20%, 25%) selama empat minggu, memilih laba tertinggi dari jadwal yang menghabiskan stok, dan membandingkannya dengan diskon tetap 20%. Hasilnya berlaku untuk asumsi yang dimasukkan.",
  },
  {
    number: "06",
    title: "Deployment",
    body: "Website ini adalah prototipe untuk eksplorasi dan pencatatan simulasi. Makalah belum melaporkan penerapan operasional di toko; hasilnya perlu divalidasi dengan data transaksi, harga pokok, dan stok aktual sebelum dipakai sebagai kebijakan harga.",
  },
];

function Panel({ title, children }) {
  return (
    <section className="rounded-lg border border-zinc-800 bg-[#111114] p-5 sm:p-6">
      <h3 className="font-medium text-white">{title}</h3>
      {children}
    </section>
  );
}

export default function Methodology() {
  return (
    <div className="max-w-6xl space-y-6">
      <div>
        <p className="text-sm leading-6 text-zinc-400">
          Alur website mengikuti CRISP-DM dan fokus makalah: optimasi markdown
          untuk sisa stok pakaian. Ringkasan dan analisis menampilkan data
          historis, sedangkan simulator menghitung skenario diskon.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {phases.map((phase) => (
          <section
            key={phase.number}
            className="rounded-lg border border-zinc-800 bg-[#111114] p-5"
          >
            <p className="font-mono text-xs text-zinc-500">{phase.number}</p>
            <h3 className="mt-3 font-medium text-white">{phase.title}</h3>
            <p className="mt-2 text-sm leading-6 text-zinc-400">
              {phase.body}
            </p>
          </section>
        ))}
      </div>

      <Panel title="Temuan yang dirujuk dari makalah dan Power BI">
        <p className="mt-3 text-sm leading-6 text-zinc-400">
          Regresi Log-Log pada 100 kombinasi toko dan produk menghasilkan 33
          koefisien elastisitas negatif dan 67 positif; median R² adalah
          0,009425. Karena daya jelasnya rendah, simulasi laporan memakai
          elastisitas asumsi −2, HPP 60% dari harga referensi, permintaan dasar
          50% dari rata-rata penjualan mingguan, stok 30.000 unit, dan target
          empat minggu.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-md border border-zinc-800 bg-zinc-950 p-4">
            <p className="text-xs text-zinc-500">Jadwal pada laporan</p>
            <p className="mt-2 text-sm text-white">15% · 15% · 15% · 20%</p>
          </div>
          <div className="rounded-md border border-zinc-800 bg-zinc-950 p-4">
            <p className="text-xs text-zinc-500">Laba kotor simulasi</p>
            <p className="mt-2 text-sm text-white">507.040,20</p>
          </div>
          <div className="rounded-md border border-zinc-800 bg-zinc-950 p-4">
            <p className="text-xs text-zinc-500">Pembanding diskon tetap 20%</p>
            <p className="mt-2 text-sm text-white">428.949,87</p>
          </div>
        </div>
        <p className="mt-4 text-xs leading-6 text-zinc-500">
          Angka tersebut adalah hasil simulasi dalam satuan nilai dataset, bukan
          laba toko yang telah diamati. Parameter sumber dan skenario pada
          simulator dapat berbeda, sehingga hasil website dapat berbeda dari
          angka laporan.
        </p>
      </Panel>

      <Panel title="Cakupan dataset">
        <p className="mt-3 text-sm leading-6 text-zinc-400">
          Gunakan file Retail Sales atau Retail Inventory yang memuat kategori
          Clothing. File Retail and wherehouse Sale memiliki kolom tahun, bulan,
          pemasok, item, tipe item, retail sales, retail transfers, dan warehouse
          sales; file tersebut berisi data minuman dan perlengkapan, tidak
          menyediakan harga atau diskon, dan bukan sumber untuk model optimasi
          pakaian ini.
        </p>
      </Panel>
    </div>
  );
}
